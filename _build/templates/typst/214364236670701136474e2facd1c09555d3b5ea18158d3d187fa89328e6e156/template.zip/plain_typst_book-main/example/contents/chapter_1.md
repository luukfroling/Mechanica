# Chapter 1

## section 1 

Here is a nice equation:
```{math}
:label: my-equation1
w_{t+1} = (1 + r_{t+1}) s(w_t) + y_{t+1}
```

And here is a figure:

```{figure} ../figures/avatar.png
:label: myFigure11
:alt: Sunset at the beach
:align: center

With a nice caption
```

```{note}
This is a note!
```


## section 2 

A second section with a reference to equation {numref}`my-equation1` and {numref}`myFigure11`.

with a [Link](https://example.com)